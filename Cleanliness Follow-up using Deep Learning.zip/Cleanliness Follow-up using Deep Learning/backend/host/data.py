import sqlite3
from datetime import date, datetime
# from flask_cors import CORS
from flask import Flask, request, jsonify, send_from_directory,redirect,session
from werkzeug.utils import secure_filename
from config import Config
import os
import pandas as pd
from twilio.rest import Client

conn = sqlite3.connect('garbage.db.sqlite')
data = pd.read_excel('fake_garbage.xlsx')
df = data.groupby(['City', 'Area', 'Year']).sum().reset_index()

conn.execute('''CREATE TABLE IF NOT EXISTS yolo
         (image TEXT,
         date DATE,
         time DATETIME,
         ADDRESS VARCHAR(50),
         mac_address VARCHAR(500),
         is_verified INT);''')

TABLE_CREATE = """CREATE TABLE IF NOT EXISTS Users (
    EMAIL VARCHAR(100) UNIQUE,
    USERNAME VARCHAR(50) PRIMARY KEY,
    PASSWORD VARCHAR(500) NOT NULL
);"""
conn.execute(TABLE_CREATE)
conn.commit()
print('table done')
app = Flask(__name__)
app.secret_key=os.urandom(24)
# CORS(app)

# Returns the current local date
today = date.today()
current_time = datetime.now().strftime("%H:%M:%S")
app.config.from_object(Config)


# message
def notification(area):
    # account_sid = 'AC3f4210252eca1758eea4a5bd6f4cda7f'
    # auth_token = '96139dc71ec8175b1b2a9891dc038541'
    # twilio_number = '+17705259056'
    # target_number = '+916351537224'

    # account_sid='ACd53a3b178e97387e98f68b3e325fe27a'
    # auth_token='ec29dfc6d179ed7165cd2addcfce0e4e'
    # twilio_number='+12056289637'
    # target_number = '+919825762824'

    account_sid='AC547c8d07a625ca55d5024341ba5cb42d'
    auth_token='708962a448560229ea685f2ee4a50370'
    twilio_number='+13465508239'
    target_number = '+919726408990'

    client = Client(account_sid, auth_token)
    message = client.messages.create(
        body=f"garbage detected in {area}",
        from_=twilio_number,
        to=target_number
    )
    print(message.body)

#**************************************************************LOGIN LOGIN LOGIN LOGIN *****************************************************************#

# EMAIL VARCHAR(100) UNIQUE,
# USERNAME VARCHAR(50) PRIMARY KEY,
# PASSWORD VARCHAR(500) NOT NULL


@app.route('/add_user/<name>/<email>/<passw>')
def add_user(name,email,passw):
    conn=sqlite3.connect('garbage.db.sqlite')
    qry = f"""INSERT INTO Users VALUES
                    ("{email}", "{name}", "{passw}")"""
    conn.execute(qry)
    conn.commit()
    return 'data added'

@app.route('/fetch_login')
def fetch_login():
    conn = sqlite3.connect('garbage.db.sqlite')
    query = 'select * from Users'
    temp = conn.execute(query).fetchall()
    conn.commit()
    data = []
    print(temp)
    # for i in temp:
    #     print(i[0])
    #     dict = {"iamge_path": i[0], "date": i[1], "time": i[2],
    #             "location": i[3], "mac_address": i[4], "approved": i[5]}
    #     data.append(dict)
    return jsonify({'data':'om'})
@app.route('/loginsucess')
def sucess():
    if "user_id" in session:
        return 'Login sucessful'
    else:
        return 'not'



@app.route('/valid/<name>/<passw>')
def login_validate(name,passw):
    conn = sqlite3.connect('garbage.db.sqlite')
    query=f"""SELECT * from Users where USERNAME ='{name}' AND PASSWORD='{passw}' """
    temp = conn.execute(query).fetchall()
    conn.commit()
    if len(temp)>0:
        # session['user_id']=temp[0][1]
        return jsonify({'Username':temp[0][1],'status':"login done"})
    else:
        return 'not matching'
    # return jsonify({'data':temp})


@app.route('/add/<addr>/<mac>', methods=['GET', 'POST'])
def data_add(addr, mac):
    print(mac)
    if request.method == 'POST':
        print("CALLED")
        file = request.files['file']

        if file.filename == '':
            return jsonify({'detail': "No image selected."})
        elif file:
            filename = secure_filename(file.filename)
            date_time = datetime.now().strftime("%Y%m%d%H%M%S.jpg")
            file.save(os.path.join(Config.UPLOAD_FOLDER, date_time))
            date = datetime.now().strftime("%Y-%m-%d")
            time = datetime.now().strftime("%H:%M:%S")
            conn = sqlite3.connect('garbage.db.sqlite')
            qry = f"""INSERT INTO yolo VALUES
                ("{date_time}", "{date}", "{time}", "{addr}", "{mac}", 0)"""
            print(qry)
            conn.execute(qry)
            conn.commit()
            return jsonify({"detail": 'Image has been successfully uploaded'})
        else:
            return jsonify({"detail": 'Allowed media types are - png, jpg, jpeg, gif'})

    return jsonify({'Date': today, 'time': current_time})


@app.route('/delete_all', methods=['GET', 'POST', 'DELETE'])
def deleteall_data():
    conn = sqlite3.connect('garbage.db.sqlite')
    query = 'DELETE FROM yolo where is_verified = 2'
    conn.execute(query)
    conn.commit()
    return "data deleted"


@app.route('/delete_row/<id>', methods=['GET', 'POST', 'DELETE'])
def deleteall_row(id):
    conn = sqlite3.connect('garbage.db.sqlite')
    query = f'DELETE FROM yolo WHERE image = "{id}"'
    conn.execute(query)
    conn.commit()
    return f"data of {id} row deleted"


@app.route('/fetch', methods=['GET'])
def get_data():
    conn = sqlite3.connect('garbage.db.sqlite')
    query = 'select * from yolo where is_verified = 0'
    temp = conn.execute(query).fetchall()
    conn.commit()
    data = []
    print(len(temp))
    for i in temp:
        print(i[0])
        dict = {"iamge_path": i[0], "date": i[1], "time": i[2],
                "location": i[3], "mac_address": i[4], "approved": i[5]}
        data.append(dict)
    return jsonify({'data': data, 'count': len(temp)})


@app.route('/count', methods=['GET'])
def get_count():
    conn = sqlite3.connect('garbage.db.sqlite')
    query = 'select * from yolo where is_verified = 0'
    temp = conn.execute(query).fetchall()
    conn.commit()
    print(len(temp))
    return jsonify({'count': len(temp)})


@app.route('/fetchv', methods=['GET'])
def get_datav():
    conn = sqlite3.connect('garbage.db.sqlite')
    query = 'select * from yolo where is_verified = 1'
    temp = conn.execute(query).fetchall()
    conn.commit()
    data = []
    # print(temp)
    for i in temp:
        print(i[0])
        dict = {"iamge_path": i[0], "date": i[1], "time": i[2],
                "location": i[3], "mac_address": i[4], "approved": i[5]}
        data.append(dict)
    return jsonify({'data': data})


@app.route("/media/<path>", methods=['GET'])
def media(path):
    print(path)
    return send_from_directory(
        directory=app.config['UPLOAD_FOLDER'], path=path
    )


@app.route('/verify/<id>/<area>', methods=['GET', 'POST'])
def verify_update(id, area):
    conn = sqlite3.connect('garbage.db.sqlite')
    query1 = f'select is_verified from yolo WHERE image = "{id}"'
    temp = conn.execute(query1).fetchall()
    temp = temp[0][0]
    if temp == 0:
        pass
    query = f'UPDATE yolo SET is_verified=1 WHERE image = "{id}"'

    if temp == 1:
        query = f'UPDATE yolo SET is_verified=0 WHERE image = "{id}"'

    conn.execute(query)
    conn.commit()
    # notification(area)
    return f"data of {id} where {temp}row updated ,message sent to {area}"


@app.route('/temp_delete/<id>', methods=['GET', 'POST'])
def temp_delete(id):
    conn = sqlite3.connect('garbage.db.sqlite')
    query1 = f'select is_verified from yolo WHERE image = "{id}"'
    temp = conn.execute(query1).fetchall()
    temp = temp[0][0]
    if temp == 0:
        pass
    query = f'UPDATE yolo SET is_verified=2 WHERE image = "{id}"'

    if temp == 2:
        query = f'UPDATE yolo SET is_verified=0 WHERE image = "{id}"'

    conn.execute(query)
    conn.commit()
    return f"data of {id} where {temp}row send to temp_delete page"


@app.route('/fetch_delete', methods=['GET'])
def get_delete():
    conn = sqlite3.connect('garbage.db.sqlite')
    query = 'select * from yolo where is_verified = 2'
    temp = conn.execute(query).fetchall()
    conn.commit()
    data = []
    # print(temp)
    for i in temp:
        print(i[0])
        dict = {"iamge_path": i[0], "date": i[1], "time": i[2],
                "location": i[3], "mac_address": i[4], "approved": i[5]}
        data.append(dict)
    return jsonify({'data': data})


@app.route('/year/<city>/<year>', methods=['GET', 'POST'])
def home(city, year):
    if year == "All":
        all_df = df.groupby(['City', 'Area']).sum().reset_index()
        filt = (all_df['City'] == city)
        temp = all_df[filt]
        temp = temp.sort_values('Count', ascending=False)
        print(temp)
    else:
        filt = (df['City'] == city) & (df['Year'] == int(year))
        temp = df[filt]
        temp = temp.sort_values('Count', ascending=False)
    l = []
    # print(temp)
    for i in range(len(temp)):
        l.append({"Area": temp.iloc[i]['Area'], "Count": int(
            temp.iloc[i]['Count']), "Year": year})

    return jsonify({"data": l})


@app.route('/local/<year>/<city>/<area>')
def area_wise(year,city,area):
    filt = (data['Area'] == area) & (data['Year'] == int(year)) & (data['City']==city)
    temp = data[filt]
    print(temp)
    l = []
    for i in range(len(temp)):
        l.append({"Area": temp.iloc[i]['Area'], "Count": int(temp.iloc[i]['Count']), "Year": year, "Month": int(temp.iloc[i]['Month'])})

    return jsonify({"data": l})


# message
@app.route('/notify/<area>')
def notification(area):
    # account_sid = 'AC3f4210252eca1758eea4a5bd6f4cda7f'
    # auth_token = '96139dc71ec8175b1b2a9891dc038541'
    # twilio_number = '+17705259056'
    # target_number = '+916351537224'

    account_sid = 'ACd53a3b178e97387e98f68b3e325fe27a'
    auth_token = 'ec29dfc6d179ed7165cd2addcfce0e4e'
    twilio_number = '+12056289637'
    target_number = '+919825762824'

    client = Client(account_sid, auth_token)
    message = client.messages.create(
        body=f"garbage detected in {area}",
        from_=twilio_number,
        to=target_number
    )
    print(message.body)
    return message.body


# drop down
@app.route('/dropdown/<city>/<area>')
def dropdown(city,area):
    filt = (df['City'] == city) & (df['Area']==area)
    temp = df[filt]
    print(temp)
    l=[]
    for i in range(len(temp)):
        l.append({"Year":int(temp.iloc[i]['Year']),"Count":int(temp.iloc[i]['Count'])})
    return jsonify({"dropdown": l})


if __name__ == "__main__":
    app.run(debug=True)





























# import sqlite3
# from datetime import date,datetime
# from flask import Flask,request,jsonify, send_from_directory
# from hashlib import sha256
# from twilio.rest import Client
#
# from werkzeug.utils import secure_filename
# from config import Config
# import os
#
# conn = sqlite3.connect('garbage.db.sqlite')
#
# conn.execute('''CREATE TABLE IF NOT EXISTS yolo
#          (image TEXT,
#          date DATE,
#          time DATETIME,
#          ADDRESS VARCHAR(50),
#          mac_address VARCHAR(500),
#          is_verified INT);''')
#
# TABLE_CREATE = """CREATE TABLE IF NOT EXISTS Users (
#     EMAIL VARCHAR(100) UNIQUE,
#     USERNAME VARCHAR(50) PRIMARY KEY,
#     PASSWORD VARCHAR(500) NOT NULL
# );"""
# conn.execute(TABLE_CREATE)
# conn.commit()
# print('table done')
# app = Flask(__name__)
# # Returns the current local date
# today = date.today()
# current_time = datetime.now().strftime("%H:%M:%S")
# app.config.from_object(Config)
#
# ADD_RECORD = "INSERT INTO Users (EMAIL, USERNAME, PASSWORD) VALUES ({}, {}, {});"
#
# def hash_password(password):
#
#     return sha256(password.encode()).hexdigest()
#
#
#
# def check_user(username, password):
#     conn = sqlite3.connect('garbage.db.sqlite')
#
#     # password = hash_password(password)
#     q = f"SELECT * FROM Users WHERE USERNAME = {username} AND PASSWORD = {password};"
#     return conn.execute(q).fetchone()
#
# @app.route('/add_user/<email>/<username>/<password>')
# def add_user(email, username, password):
#     conn = sqlite3.connect('garbage.db.sqlite')
#     # password = hash_password(password)
#     password=str(password)
#     q = ADD_RECORD.format(email, username, password)
#     conn.execute(q)
#     conn.commit()
#     return f"pass={password}"
# @app.route('/notify/<area>')
# def notification(area):
#     # account_sid = 'AC3f4210252eca1758eea4a5bd6f4cda7f'
#     # auth_token = '96139dc71ec8175b1b2a9891dc038541'
#     # twilio_number = '+17705259056'
#     # target_number = '+916351537224'
#
#     account_sid='ACd53a3b178e97387e98f68b3e325fe27a'
#     auth_token='ec29dfc6d179ed7165cd2addcfce0e4e'
#     twilio_number='+12056289637'
#     target_number = '+919825762824'
#
#     client = Client(account_sid, auth_token)
#     message = client.messages.create(
#         body=f"garbage detected in {area}",
#         from_=twilio_number,
#         to=target_number
#     )
#     print(message.body)
#     return message.body
#
#
#
# @app.route('/login', methods=['POST'])
# def login():
#     username = request.json.get('username')
#     password = request.json.get('password')
#     if check_user(username, password):
#         return "login"
#     return 'not login '
#
# @app.route('/add/<addr>/<mac>', methods=['GET', 'POST'])
# def data_add(addr, mac):
#     print(mac)
#     if request.method == 'POST':
#         print("CALLED")
#         file = request.files['file']
#
#         if file.filename == '':
#             return jsonify({'detail': "No image selected."})
#         elif file:
#             filename = secure_filename(file.filename)
#             date_time = datetime.now().strftime("%Y%m%d%H%M%S.jpg")
#             file.save(os.path.join(Config.UPLOAD_FOLDER, date_time))
#
#             date = datetime.now().strftime("%Y-%m-%d")
#             time = datetime.now().strftime("%H:%M:%S")
#             conn = sqlite3.connect('garbage.db.sqlite')
#             qry = f"""INSERT INTO yolo VALUES
#                 ("{date_time}", "{date}", "{time}", "{addr}", "{mac}", 0)"""
#             print(qry)
#             conn.execute(qry)
#             conn.commit()
#             return jsonify({"detail": 'Image has been successfully uploaded'})
#         else:
#             return jsonify({"detail": 'Allowed media types are - png, jpg, jpeg, gif'})
#     return jsonify({'Date': today, 'time': current_time})
# @app.route('/delete_all',methods=['GET','POST'])
# def deleteall_data():
#     conn = sqlite3.connect('garbage.db.sqlite')
#     query = 'DELETE FROM yolo'
#     conn.execute(query)
#     conn.commit()
#     return "data deleted"
#
# @app.route('/delete_row/<id>',methods=['GET','POST'])
# def deleteall_row(id):
#     conn = sqlite3.connect('garbage.db.sqlite')
#     query = f'DELETE FROM yolo WHERE image = "{id}"'
#     conn.execute(query)
#     conn.commit()
#     return f"data of {id} row deleted"
# @app.route('/verify/<id>',methods=['GET','POST'])
# def verify_update(id):
#     conn = sqlite3.connect('garbage.db.sqlite')
#     query1 = f'select is_verified from yolo WHERE image = "{id}"'
#     temp = conn.execute(query1).fetchall()
#     temp=temp[0][0]
#     if temp==0:
#         pass
#     query = f'UPDATE yolo SET is_verified=1 WHERE image = "{id}"'
#
#     if temp==1:
#         query = f'UPDATE yolo SET is_verified=0 WHERE image = "{id}"'
#
#     conn.execute(query)
#     conn.commit()
#     return f"data of {id} where {temp}row updated"
#
#
#
# @app.route('/fetch',methods=['GET'])
# def get_data():
#     conn = sqlite3.connect('garbage.db.sqlite')
#     query='select * from yolo'
#     temp=conn.execute(query).fetchall()
#     conn.commit()
#     data=[]
#     # print(temp)
#     for i in temp:
#         print(i[0])
#         dict={"iamge_path":i[0],"date":i[1],"time":i[2],"location":i[3],"mac_address":i[4],"approved":i[5]}
#         data.append(dict)
#     return jsonify({'Data':data})
#
#
# @app.route("/media/<path>", methods=['GET'])
# def media(path):
#     print(path)
#     return send_from_directory(
#         directory=app.config['UPLOAD_FOLDER'], path=path
#     )
#
# if __name__ =="__main__":
#     app.run(debug=True)
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
