import sqlite3
from datetime import date,datetime
from flask import Flask,request,jsonify, send_from_directory
from hashlib import sha256
from twilio.rest import Client

from werkzeug.utils import secure_filename
from config import Config
import os

conn = sqlite3.connect('garbage.db.sqlite')

conn.execute('''CREATE TABLE IF NOT EXISTS yolo
         (image TEXT,
         date DATE,
         time DATETIME,
         ADDRESS VARCHAR(50),
         mac_address VARCHAR(500),
         is_verified INT);''')

TABLE_CREATE = """CREATE TABLE IF NOT EXISTS Users (
    EMAIL VARCHAR(100) UNIQUE,
    USERNAME VARCHAR(50) PRIMARY KEY,
    PASSWORD VARCHAR(500) NOT NULL
);"""
conn.execute(TABLE_CREATE)
conn.commit()
print('table done')
app = Flask(__name__)
# Returns the current local date
today = date.today()
current_time = datetime.now().strftime("%H:%M:%S")
app.config.from_object(Config)

ADD_RECORD = "INSERT INTO Users (EMAIL, USERNAME, PASSWORD) VALUES ({}, {}, {});"

def hash_password(password):

    return sha256(password.encode()).hexdigest()



def check_user(username, password):
    conn = sqlite3.connect('garbage.db.sqlite')

    # password = hash_password(password)
    q = f"SELECT * FROM Users WHERE USERNAME = {username} AND PASSWORD = {password};"
    return conn.execute(q).fetchone()

@app.route('/add_user/<email>/<username>/<password>')
def add_user(email, username, password):
    conn = sqlite3.connect('garbage.db.sqlite')
    # password = hash_password(password)
    password=str(password)
    q = ADD_RECORD.format(email, username, password)
    conn.execute(q)
    conn.commit()
    return f"pass={password}"


@app.route('/login', methods=['POST'])
def login():
    username = request.json.get('username')
    password = request.json.get('password')
    if check_user(username, password):
        return "login"
    return 'not login '

@app.route('/add/<addr>/<mac>', methods=['GET', 'POST'])
def data_add(addr, mac):
    print(mac)
    if request.method == 'POST':
        print("CALLED")
        file = request.files['file']

        if file.filename == '':
            return jsonify({'detail': "No image selected."})
        elif file:
            filename = secure_filename(file.filename)
            date_time = datetime.now().strftime("%Y%m%d%H%M%S.jpg")
            file.save(os.path.join(Config.UPLOAD_FOLDER, date_time))

            date = datetime.now().strftime("%Y-%m-%d")
            time = datetime.now().strftime("%H:%M:%S")
            conn = sqlite3.connect('garbage.db.sqlite')
            qry = f"""INSERT INTO yolo VALUES
                ("{date_time}", "{date}", "{time}", "{addr}", "{mac}", 0)"""
            print(qry)
            conn.execute(qry)
            conn.commit()
            return jsonify({"detail": 'Image has been successfully uploaded'})
        else:
            return jsonify({"detail": 'Allowed media types are - png, jpg, jpeg, gif'})
    return jsonify({'Date': today, 'time': current_time})
@app.route('/delete_all',methods=['GET','POST'])
def deleteall_data():
    conn = sqlite3.connect('garbage.db.sqlite')
    query = 'DELETE FROM yolo'
    conn.execute(query)
    conn.commit()
    return "data deleted"

@app.route('/delete_row/<id>',methods=['GET','POST'])
def deleteall_row(id):
    conn = sqlite3.connect('garbage.db.sqlite')
    query = f'DELETE FROM yolo WHERE image = "{id}"'
    conn.execute(query)
    conn.commit()
    return f"data of {id} row deleted"
@app.route('/verify/<id>',methods=['GET','POST'])
def verify_update(id):
    conn = sqlite3.connect('garbage.db.sqlite')
    query1 = f'select is_verified from yolo WHERE image = "{id}"'
    temp = conn.execute(query1).fetchall()
    temp=temp[0][0]
    if temp==0:
        pass
    query = f'UPDATE yolo SET is_verified=1 WHERE image = "{id}"'

    if temp==1:
        query = f'UPDATE yolo SET is_verified=0 WHERE image = "{id}"'

    conn.execute(query)
    conn.commit()
    return f"data of {id} where {temp}row updated"



@app.route('/fetch',methods=['GET'])
def get_data():
    conn = sqlite3.connect('garbage.db.sqlite')
    query='select * from yolo'
    temp=conn.execute(query).fetchall()
    conn.commit()
    data=[]
    # print(temp)
    for i in temp:
        print(i[0])
        dict={"iamge_path":i[0],"date":i[1],"time":i[2],"location":i[3],"mac_address":i[4],"approved":i[5]}
        data.append(dict)
    return jsonify({'Data':data})


@app.route("/media/<path>", methods=['GET'])
def media(path):
    print(path)
    return send_from_directory(
        directory=app.config['UPLOAD_FOLDER'], path=path
    )

if __name__ =="__main__":
    app.run(debug=True)
